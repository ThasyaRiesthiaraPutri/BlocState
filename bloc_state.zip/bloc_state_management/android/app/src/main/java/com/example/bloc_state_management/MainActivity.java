package com.example.bloc_state_management;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
