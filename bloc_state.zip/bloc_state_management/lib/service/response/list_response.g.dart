// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'list_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ListResponse _$ListResponseFromJson(Map<String, dynamic> json) => ListResponse(
      elixirs: (json['elixirs'] as List<dynamic>)
          .map((e) => ElixirsData.fromJson(e as Map<String, dynamic>))
          .toList(),
      id: json['id'] as String,
      firstName: json['firstName'] ?? "",
      lastName: json['lastName'] ?? "",
    );

Map<String, dynamic> _$ListResponseToJson(ListResponse instance) =>
    <String, dynamic>{
      'elixirs': instance.elixirs,
      'id': instance.id,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
    };

ElixirsData _$ElixirsDataFromJson(Map<String, dynamic> json) => ElixirsData()
  ..id = json['id'] as String?
  ..name = json['name'] as String?;

Map<String, dynamic> _$ElixirsDataToJson(ElixirsData instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
