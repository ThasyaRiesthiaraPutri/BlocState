import 'package:json_annotation/json_annotation.dart';

part 'list_response.g.dart';

@JsonSerializable()
class ListResponse {
  final List<ElixirsData>? elixirs;
  final String? id;
  final String? firstName;
  final String? lastName;

  ListResponse({
     this.elixirs,
     this.id,
     this.firstName,
     this.lastName,
});

  factory ListResponse.fromJson(Map<String, dynamic> json) => _$ListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ListResponseToJson(this);
}

@JsonSerializable()
class ElixirsData {
  String? id;
  String? name;

  ElixirsData();

  factory ElixirsData.fromJson(Map<String, dynamic> json) => _$ElixirsDataFromJson(json);

  Map<String, dynamic> toJson() => _$ElixirsDataToJson(this);
}
