import 'dart:convert';

import 'package:bloc_state_management/service/response/list_response.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';

class ListService {
  //http
  Future<List<ListResponse>> httpFetchListData() async {
    try {
      final response = await http
          .get(Uri.parse('https://wizard-world-api.herokuapp.com/wizards'));
      if (response.statusCode == 200) {
        final List result = json.decode(response.body);
        return result.map((data) => ListResponse.fromJson(data))
            .toList();
      } else {
        throw Exception('Failed to fetch data.');
      }
    } catch (e) {
      throw Exception('Failed to fetch data.');
    }
  }

  //dio
  Future<List<ListResponse>?> dioFetchListData() async {
    try {
      final response = await Dio()
          .get('https://wizard-world-api.herokuapp.com/wizards');
      if (response.statusCode == 200) {
        final jsonData = response.data;
        return (jsonData as List<dynamic>)
            .map((data) => ListResponse.fromJson(data))
            .toList();
      } else {
        throw Exception('Failed to fetch data.');
      }
    } catch (e) {
      throw Exception('Failed to fetch data.');
    }
  }
}