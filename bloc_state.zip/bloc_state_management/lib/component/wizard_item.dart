import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class WizardComponent extends StatefulWidget {
  const WizardComponent({Key? key,
    this.id,
    this.firstName,
    this.lastName,
    this.totalElixir,
    this.onTap,
  }) : super(key: key);

  final String? id;
  final String? firstName;
  final String? lastName;
  final String? totalElixir;
  final VoidCallback? onTap;

  @override
  State<WizardComponent> createState() => _WizardComponentState();
}

class _WizardComponentState extends State<WizardComponent> {

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        widget.onTap;
      },
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        color: Colors.teal,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Container(
                margin: const EdgeInsets.only(right: 10),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
                width: 50,
                height: 50,
                child: const Icon(
                  Icons.person_outline_sharp,
                  color: Colors.lightBlue,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children:  [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 40/100,
                    child: Text(
                      widget.id ?? "ID",
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, color: Colors.white),
                    ),
                  ),
                  Text(
                    widget.firstName ?? "First Name",
                    style: const TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  Text(
                    widget.lastName ?? "Last Name",
                    style: const TextStyle(fontSize: 20, color: Colors.white),
                  ),
                ],
              ),
              Flexible(
                  child: Container(
                    width: double.infinity,
                  )),
              Column(
                children: [
                  const Text("Total Elixir",
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                  Text(widget.totalElixir ?? "0",
                      style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                ],
              ),
              // const Icon(Icons.arrow_forward_ios, color: Colors.white,),
            ],
          ),
        ),
      ),
    );
  }
}
