import 'package:bloc_state_management/bloc/wizard_bloc.dart';
import 'package:bloc_state_management/bloc/wizard_state.dart';
import 'package:bloc_state_management/component/wizard_item.dart';
import 'package:bloc_state_management/service/list_service.dart';
import 'package:bloc_state_management/service/response/list_response.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/wizard_event.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => WizardBloc(
        RepositoryProvider.of<ListService>(context),
      )..add(LoadingEvent()),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Coding 1"),
        ),
        body: BlocBuilder<WizardBloc, WizardState>(
          builder: (context, state) {
            if (state is LoadingState) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (state is LoadedState) {
              List<ListResponse> dataList = state.listResponse;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: ListView.builder(
                    itemCount: dataList.length,
                    itemBuilder: (_, index) {
                      return WizardComponent(
                        onTap: () {

                        },
                        id: dataList[index].id,
                        firstName: dataList[index].firstName == "" ? "-" : dataList[index].firstName,
                        lastName: dataList[index].lastName,
                        totalElixir: dataList[index].elixirs!.length.toString(),
                      );
                    }),
              );
            }
            return Container();
          },
        ),
      ),
    );
  }
}
