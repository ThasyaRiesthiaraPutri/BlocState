import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../service/response/list_response.dart';

@immutable
abstract class WizardState extends Equatable {}

class LoadingState extends WizardState {
  @override
  List<Object?> get props => [];
}

class LoadedState extends WizardState {
  LoadedState(this.listResponse);

  final List<ListResponse> listResponse;

  @override
  List<Object?> get props => [listResponse];
}

class ErrorState extends WizardState {
  ErrorState(this.error);

  final String error;

  @override
  List<Object?> get props => [error];
}