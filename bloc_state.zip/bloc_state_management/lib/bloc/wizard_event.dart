import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

@immutable
abstract class WizardEvent extends Equatable {
  const WizardEvent();
}

class LoadingEvent extends WizardEvent {
  @override
  List<Object?> get props => [];
}