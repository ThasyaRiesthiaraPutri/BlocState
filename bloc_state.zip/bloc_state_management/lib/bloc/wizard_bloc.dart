
import 'package:bloc_state_management/bloc/wizard_event.dart';
import 'package:bloc_state_management/bloc/wizard_state.dart';
import 'package:bloc_state_management/service/list_service.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class WizardBloc extends Bloc<WizardEvent, WizardState> {
  final ListService _listService;

  WizardBloc(this._listService) : super(LoadingState()) {
    on<LoadingEvent>((event, emit) async {
      emit(LoadingState());

      try{
        final data = await _listService.httpFetchListData();
        emit(LoadedState(data));
      } catch (e) {
        emit(ErrorState(e.toString()));
      }
    });
  }
}