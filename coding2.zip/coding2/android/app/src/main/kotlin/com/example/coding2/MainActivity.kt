package com.example.coding2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
