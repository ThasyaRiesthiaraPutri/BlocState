import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CounterScreen extends StatefulWidget {
  const CounterScreen({super.key});

  @override
  _CounterScreenState createState() => _CounterScreenState();
}

class _CounterScreenState extends State<CounterScreen> {
  int counter = 0;
  Timer? timer;
  // FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  // FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    // initializeNotifications();
  }

  // void initializeNotifications() async {
  //   var initializationSettingsAndroid =
  //   const AndroidInitializationSettings('app_icon');
  //   var initializationSettings = InitializationSettings(
  //     android: initializationSettingsAndroid,
  //   );
  //   await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  // }

  void startTimer() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 5), (timer) {
      setState(() {
        counter++;
        print("Counter: $counter");
        if (counter % 6 == 0) {
          // showPushNotification();
        }
      });
    });
  }

  void stopTimer() {
    timer?.cancel();
  }

  void continueTimer() {
    startTimer();
  }

  void resetCounter() {
    setState(() {
      counter = 0;
      stopTimer();
    });
  }

  // void showPushNotification() async {
  //   var androidPlatformChannelSpecifics = const AndroidNotificationDetails(
  //     'channel_id',
  //     'channel_name',
  //     'channel_description',
  //     importance: Importance.max,
  //     priority: Priority.high,
  //     playSound: true,
  //     enableVibration: true,
  //     fullScreenIntent: true,
  //   );
  //   var platformChannelSpecifics = NotificationDetails(
  //     android: androidPlatformChannelSpecifics,
  //   );
  //
  //   await flutterLocalNotificationsPlugin.show(
  //     0,
  //     'Counter Update',
  //     'Current Value: $counter',
  //     platformChannelSpecifics,
  //   );
  // }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Counter App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Counter: $counter',
              style: TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: startTimer,
                  child: const Text('Start'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: stopTimer,
                  child: const Text('Stop'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: continueTimer,
                  child: const Text('Continue'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: resetCounter,
                  child: const Text('Reset'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}