// import 'package:firebase_messaging/firebase_messaging.dart';
//
// class PushNotificationService {
//   final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
//
//   Future<void> initialize() async {
//     FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
//     FirebaseMessaging.onMessage.listen(_firebaseMessagingForegroundHandler);
//     FirebaseMessaging.onMessageOpenedApp.listen(_firebaseMessagingOpenAppHandler);
//
//     // Request permission if needed
//     NotificationSettings settings = await _firebaseMessaging.requestPermission();
//     if (settings.authorizationStatus == AuthorizationStatus.authorized) {
//       // Permission granted
//       String? token = await _firebaseMessaging.getToken();
//       print('Firebase token: $token');
//     }
//   }
//
//   Future<void> _firebaseMessagingForegroundHandler(RemoteMessage message) async {
//     print('Foreground message: ${message.notification?.body}');
//   }
//
//   Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
//     print('Background message: ${message.notification?.body}');
//   }
//
//   Future<void> _firebaseMessagingOpenAppHandler(RemoteMessage message) async {
//     print('Opened app from terminated state: ${message.notification?.body}');
//   }
// }